import { UserState, ActivityLog } from '../types';

// CONFIGURATION
// Set this to true if you have the PostgreSQL server running locally
const USE_BACKEND = false; 
const API_URL = 'http://localhost:3001/api';

const DB_KEY = 'clara_db_users';
const SESSION_KEY = 'clara_session_user';

interface DBUser extends UserState {
  passwordHash: string;
}

// --- LocalStorage Helpers (Fallback) ---
const getDatabase = (): Record<string, DBUser> => {
  const dbStr = localStorage.getItem(DB_KEY);
  return dbStr ? JSON.parse(dbStr) : {};
};

const saveDatabase = (db: Record<string, DBUser>) => {
  localStorage.setItem(DB_KEY, JSON.stringify(db));
};

// --- Service Implementation ---

export const authService = {
  register: async (username: string, password: string): Promise<UserState> => {
    if (USE_BACKEND) {
      const res = await fetch(`${API_URL}/register`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || 'Registration failed');
      }
      const user = await res.json();
      localStorage.setItem(SESSION_KEY, JSON.stringify(user));
      return user;
    } 
    
    // LocalStorage Fallback
    else {
      await new Promise(resolve => setTimeout(resolve, 800));
      const db = getDatabase();
      if (db[username]) throw new Error('Username already exists');
      
      const newUser: DBUser = {
        username,
        name: username,
        passwordHash: password,
        subjects: [],
        isOnboarded: false,
        streak: 0,
        lastLoginDate: new Date().toISOString().split('T')[0],
        confidenceHistory: [],
        activityLog: []
      };
      
      db[username] = newUser;
      saveDatabase(db);
      localStorage.setItem(SESSION_KEY, JSON.stringify(newUser));
      return newUser;
    }
  },

  login: async (username: string, password: string): Promise<UserState> => {
    if (USE_BACKEND) {
      const res = await fetch(`${API_URL}/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || 'Login failed');
      }
      const user = await res.json();
      localStorage.setItem(SESSION_KEY, JSON.stringify(user));
      return user;
    }

    // LocalStorage Fallback
    else {
      await new Promise(resolve => setTimeout(resolve, 800));
      const db = getDatabase();
      const user = db[username];
      if (!user || user.passwordHash !== password) throw new Error('Invalid username or password');
      
      user.lastLoginDate = new Date().toISOString().split('T')[0];
      db[username] = user;
      saveDatabase(db);
      localStorage.setItem(SESSION_KEY, JSON.stringify(user));
      return user;
    }
  },

  getCurrentUser: (): UserState | null => {
    const sessionStr = localStorage.getItem(SESSION_KEY);
    if (!sessionStr) return null;
    return JSON.parse(sessionStr);
  },

  updateUser: async (user: UserState) => {
    // Always update local session for UI responsiveness
    localStorage.setItem(SESSION_KEY, JSON.stringify(user));

    if (USE_BACKEND) {
       try {
           await fetch(`${API_URL}/user/update`, {
               method: 'PUT',
               headers: { 'Content-Type': 'application/json' },
               body: JSON.stringify(user)
           });
       } catch (e) {
           console.error("Failed to sync with backend", e);
       }
    } else {
        const db = getDatabase();
        if (db[user.username]) {
            db[user.username] = { ...db[user.username], ...user };
            saveDatabase(db);
        }
    }
  },

  // Specialized logging to prevent huge payloads in updateUser
  logActivity: async (username: string, log: ActivityLog) => {
      if (USE_BACKEND) {
          try {
             await fetch(`${API_URL}/log`, {
                 method: 'POST',
                 headers: { 'Content-Type': 'application/json' },
                 body: JSON.stringify({ username, log })
             });
          } catch (e) { console.error("Log sync failed", e); }
      }
      // Note: LocalStorage sync for logs is handled via the bulk updateUser call in App.tsx for the mockup
  },

  logout: () => {
    localStorage.removeItem(SESSION_KEY);
  }
};
