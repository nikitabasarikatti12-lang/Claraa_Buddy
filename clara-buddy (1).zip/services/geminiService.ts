import { GoogleGenAI, Type } from "@google/genai";
import { Subject, QuizQuestion } from "../types";

// Initialize Gemini
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const MODEL_NAME = 'gemini-3-flash-preview';

interface DailyContentResponse {
  topics: { title: string; content: string }[];
  quizQuestions: QuizQuestion[];
}

export const generateSubjectDailyContent = async (subject: Subject): Promise<DailyContentResponse> => {
  try {
    // Construct syllabus context from User Input
    const syllabusContext = subject.chapters
      .map((c, i) => `Chapter ${i + 1}: ${c.title} (Topics: ${c.details})`)
      .join('\n');

    // Determine difficulty and tone based on score
    // Explicitly targeting anxiety reduction in lower confidence tiers
    let difficultyInstruction = "";
    if (subject.currentScore < 40) {
      difficultyInstruction = "Tone: Extremely soothing, encouraging, and simple. Focus: Core definitions only to build confidence. Reduce anxiety.";
    } else if (subject.currentScore < 75) {
      difficultyInstruction = "Tone: Professional but supportive. Focus: Application of concepts.";
    } else {
      difficultyInstruction = "Tone: Academic and challenging. Focus: Advanced nuances.";
    }

    // Optimized prompt to reduce token usage
    const prompt = `
      Tutor: Clara (Anxiety-reducing study companion). Subject: ${subject.name}
      Syllabus: ${syllabusContext}
      
      Task:
      1. Pick 2 "Micro-Learning Tasks" from syllabus.
      2. Write a 400-word study guide for each.
         - Format: Markdown (##, **, -).
         - Structure: Intro (Why this matters), Core Concept (Simplified), Example (Real world), Summary.
         - Key Goal: Make it feel "doable" to reduce anxiety.
      3. Create 5 MCQ Quiz Questions based ONLY on generated guides.
      
      ${difficultyInstruction}
      
      Return JSON.
    `;

    const response = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            topics: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  title: { type: Type.STRING },
                  content: { type: Type.STRING },
                },
              },
            },
            quizQuestions: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  id: { type: Type.STRING },
                  question: { type: Type.STRING },
                  options: { type: Type.ARRAY, items: { type: Type.STRING } },
                  correctOptionIndex: { type: Type.INTEGER },
                  explanation: { type: Type.STRING },
                },
              },
            }
          },
        },
      },
    });

    const json = JSON.parse(response.text || '{"topics": [], "quizQuestions": []}');
    
    if (!json.topics || json.topics.length === 0) throw new Error("No content generated");

    return json;
  } catch (error: any) {
    // Robust 429 detection
    const isRateLimit = 
        error?.status === 429 || 
        error?.code === 429 || 
        error?.message?.includes('429') || 
        error?.message?.includes('quota') ||
        (error?.error && error?.error?.code === 429); // Check nested error object
    
    if (isRateLimit) {
        console.warn(`Rate limit hit for ${subject.name}. Switching to offline fallback.`);
    } else {
        console.error(`Error generating content for ${subject.name}:`, error);
    }

    // Fallback Content (Offline Mode)
    return {
      topics: [
        { 
            title: `Review: ${subject.name} (Offline Mode)`, 
            content: `## High Traffic Volume\n\nOur AI tutors are currently at maximum capacity. While we cool down the servers, please stick to the basics for **${subject.name}**.\n\n### Today's Manual Task\n1. Open your textbook to the current chapter.\n2. Read the summary section.\n3. Write down 3 key definitions in your notebook.\n\n*This content is a placeholder while we reconnect.*` 
        },
        { 
            title: "Quick Revision", 
            content: "## Active Recall\n\nClose your eyes and try to mentally visualize the last concept you learned in this subject. Can you explain it to a 5-year-old? If not, review it again." 
        }
      ],
      quizQuestions: [
          {
              id: "fb1", question: "True or False: Spaced repetition is more effective than cramming.", options: ["True", "False", "Both are equal", "Neither"], correctOptionIndex: 0, explanation: "Spaced repetition is scientifically proven to improve long-term retention."
          },
          {
              id: "fb2", question: "What should you do if you feel overwhelmed?", options: ["Quit", "Take a small break", "Study harder", "Skip sleep"], correctOptionIndex: 1, explanation: "Short breaks help reset your focus and reduce cognitive load."
          },
          {
              id: "fb3", question: "What is the 'Feynman Technique'?", options: ["Eating while studying", "Explaining concepts simply", "Reading quickly", "Highlighting everything"], correctOptionIndex: 1, explanation: "It involves explaining a concept in simple terms to ensure you truly understand it."
          },
          {
              id: "fb4", question: "Which is a sign of burnout?", options: ["Feeling energized", "Consistent exhaustion", "High motivation", "Sleeping well"], correctOptionIndex: 1, explanation: "Chronic exhaustion and detachment are key signs of burnout."
          },
          {
              id: "fb5", question: "What is the goal of Clara Buddy?", options: ["To replace teachers", "To increase anxiety", "To support your learning", "To write your exams"], correctOptionIndex: 2, explanation: "Clara is here to reduce anxiety and support your daily study habits."
          }
      ]
    };
  }
};

export const generateEncouragement = async (
  name: string,
  streak: number,
  confidenceHistory: { date: string; score: number }[]
): Promise<{ message: string; reason: string }> => {
  try {
    const historyStr = JSON.stringify(confidenceHistory.slice(-5));
    const prompt = `
      Role: Compassionate, anxiety-reducing study friend. User: ${name}. Streak: ${streak}. Confidence Trend: ${historyStr}.
      Task: Short encouraging msg (max 15 words) + reason.
      Constraint: If confidence is low, focus on "small steps" or "it's okay to rest".
      Return JSON.
    `;

    const response = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            message: { type: Type.STRING },
            reason: { type: Type.STRING },
          },
        },
      },
    });

    return JSON.parse(response.text || '{"message": "You got this!", "reason": "Consistency matters"}');
  } catch (error) {
    return { message: "Stay consistent!", reason: "Small steps lead to big progress." };
  }
};