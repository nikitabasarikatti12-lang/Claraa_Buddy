import React, { useMemo } from 'react';
import { ActivityLog } from '../types';
import { ArrowLeft, BookOpen, Award, Calendar, Clock } from 'lucide-react';

interface Props {
  logs: ActivityLog[];
  onBack: () => void;
}

const History: React.FC<Props> = React.memo(({ logs, onBack }) => {
  // Sort logs by date descending using useMemo to avoid resorting on every render
  const sortedLogs = useMemo(() => {
    return [...logs].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [logs]);

  const formatDate = (isoString: string) => {
    const date = new Date(isoString);
    return new Intl.DateTimeFormat('en-US', {
      month: 'short',
      day: 'numeric',
      hour: 'numeric',
      minute: 'numeric',
    }).format(date);
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col items-center p-4 md:p-8 font-sans">
      <div className="max-w-3xl w-full">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <button 
            onClick={onBack}
            className="p-2 hover:bg-white rounded-full transition-colors text-gray-600 hover:text-gray-900 shadow-sm border border-transparent hover:border-gray-200"
          >
            <ArrowLeft size={24} />
          </button>
          <h1 className="text-3xl font-bold text-gray-900">Your Journey</h1>
        </div>

        {/* Stats Summary */}
        <div className="grid grid-cols-2 gap-4 mb-8">
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 flex flex-col items-center text-center">
            <div className="bg-green-100 p-3 rounded-full text-green-600 mb-3">
              <BookOpen size={24} />
            </div>
            <span className="text-2xl font-bold text-gray-800">
              {logs.filter(l => l.type === 'STUDY').length}
            </span>
            <span className="text-sm text-gray-500 font-medium">Study Sessions</span>
          </div>
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 flex flex-col items-center text-center">
            <div className="bg-indigo-100 p-3 rounded-full text-indigo-600 mb-3">
              <Award size={24} />
            </div>
            <span className="text-2xl font-bold text-gray-800">
              {logs.filter(l => l.type === 'QUIZ').length}
            </span>
            <span className="text-sm text-gray-500 font-medium">Quizzes Taken</span>
          </div>
        </div>

        {/* Timeline */}
        {sortedLogs.length === 0 ? (
          <div className="text-center py-20 bg-white rounded-3xl border border-gray-100 border-dashed">
            <Calendar size={48} className="mx-auto text-gray-300 mb-4" />
            <h3 className="text-xl font-semibold text-gray-600">No activity yet</h3>
            <p className="text-gray-400 mt-2">Complete a study goal or quiz to see it here!</p>
          </div>
        ) : (
          <div className="space-y-4">
            {sortedLogs.map((log) => (
              <div 
                key={log.id} 
                className="bg-white p-5 rounded-2xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow flex items-center gap-4"
              >
                <div className={`p-3 rounded-xl shrink-0 ${log.type === 'STUDY' ? 'bg-green-50 text-green-600' : 'bg-indigo-50 text-indigo-600'}`}>
                  {log.type === 'STUDY' ? <BookOpen size={24} /> : <Award size={24} />}
                </div>
                
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-xs font-bold uppercase tracking-wider text-gray-400">
                      {log.subjectName}
                    </span>
                    <span className="text-gray-300">•</span>
                    <span className="text-xs text-gray-400 flex items-center gap-1">
                      <Clock size={12} /> {formatDate(log.date)}
                    </span>
                  </div>
                  <h3 className="font-semibold text-gray-800 truncate">{log.title}</h3>
                </div>

                <div className="text-right shrink-0">
                  <span className={`inline-block px-3 py-1 rounded-full text-xs font-bold ${
                    log.type === 'STUDY' 
                      ? 'bg-gray-100 text-gray-600' 
                      : 'bg-indigo-100 text-indigo-700'
                  }`}>
                    {log.metric}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
});

export default History;