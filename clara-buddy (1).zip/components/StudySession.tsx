import React from 'react';
import { MicroGoal } from '../types';
import { Check, ArrowLeft, BookOpen } from 'lucide-react';
import ReactMarkdown from 'react-markdown';

interface Props {
  goal: MicroGoal;
  onComplete: () => void;
  onExit: () => void;
}

const StudySession: React.FC<Props> = React.memo(({ goal, onComplete, onExit }) => {

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Top Bar */}
      <div className="bg-white shadow-sm border-b border-gray-100 p-4 sticky top-0 z-10">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <button onClick={onExit} className="text-gray-500 hover:text-gray-800 flex items-center gap-2 transition-colors">
            <ArrowLeft size={20} /> <span className="font-medium">Exit Session</span>
          </button>
          <div className="flex items-center gap-2 font-mono text-sm md:text-base font-bold text-gray-800 bg-gray-100 px-4 py-1.5 rounded-full">
            <BookOpen size={18} className="text-indigo-500" />
            <span>Focus Mode</span>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 max-w-3xl mx-auto w-full p-4 md:p-8">
        <div className="bg-white rounded-3xl shadow-lg shadow-gray-100 border border-gray-200 overflow-hidden">
          
          <div className="p-8 md:p-12">
            <div className="flex flex-col gap-4 mb-8 border-b border-gray-100 pb-8">
                <span className="inline-flex self-start items-center px-3 py-1 bg-indigo-50 text-indigo-600 rounded-full text-xs font-bold tracking-wide uppercase">
                Study Topic
                </span>
                <h1 className="text-3xl md:text-4xl font-bold text-gray-900 leading-tight">{goal.title}</h1>
            </div>
            
            <div className="prose prose-lg prose-indigo max-w-none text-gray-700 leading-relaxed font-sans">
              <ReactMarkdown 
                components={{
                    h1: ({node, ...props}) => <h1 className="text-2xl font-bold text-gray-900 mt-8 mb-4" {...props} />,
                    h2: ({node, ...props}) => <h2 className="text-xl font-bold text-gray-800 mt-8 mb-4 border-l-4 border-indigo-500 pl-4" {...props} />,
                    h3: ({node, ...props}) => <h3 className="text-lg font-bold text-gray-800 mt-6 mb-3" {...props} />,
                    p: ({node, ...props}) => <p className="mb-4 leading-7 text-gray-700" {...props} />,
                    ul: ({node, ...props}) => <ul className="list-disc pl-5 mb-4 space-y-2" {...props} />,
                    li: ({node, ...props}) => <li className="text-gray-700 pl-1" {...props} />,
                    strong: ({node, ...props}) => <strong className="font-bold text-indigo-900" {...props} />,
                    blockquote: ({node, ...props}) => <blockquote className="border-l-4 border-gray-200 pl-4 italic text-gray-500 my-4" {...props} />
                }}
              >
                {goal.content}
              </ReactMarkdown>
            </div>
          </div>
          
          <div className="p-6 bg-gray-50 border-t border-gray-100 flex justify-end sticky bottom-0">
             <button 
              onClick={onComplete}
              className="bg-green-600 text-white px-8 py-4 rounded-2xl font-bold text-lg shadow-xl shadow-green-200 hover:bg-green-700 hover:shadow-2xl hover:scale-105 transition-all flex items-center gap-2"
            >
              <Check size={24} /> Mark as Complete
            </button>
          </div>
        </div>
      </div>
    </div>
  );
});

export default StudySession;