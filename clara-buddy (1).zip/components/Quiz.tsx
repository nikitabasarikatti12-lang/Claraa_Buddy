import React, { useState } from 'react';
import { QuizQuestion } from '../types';
import { Check, X, AlertCircle, ArrowRight, Award } from 'lucide-react';

interface Props {
  questions: QuizQuestion[];
  onComplete: (score: number) => void;
}

const Quiz: React.FC<Props> = React.memo(({ questions, onComplete }) => {
  const [currentQIndex, setCurrentQIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [score, setScore] = useState(0);

  // Safety check if questions are missing
  if (!questions || questions.length === 0) {
      return <div className="p-8 text-center">No questions available.</div>;
  }

  const question = questions[currentQIndex];

  const handleSubmitAnswer = () => {
    if (selectedOption === null) return;
    
    setIsSubmitted(true);
    const isCorrect = selectedOption === question.correctOptionIndex;
    if (isCorrect) setScore(s => s + 1);
  };

  const handleNext = () => {
    if (currentQIndex < questions.length - 1) {
      setCurrentQIndex(c => c + 1);
      setSelectedOption(null);
      setIsSubmitted(false);
    } else {
      // Calculate final score percentage based on TOTAL questions
      // The score state holds the count of correct answers so far
      const finalScore = Math.round((score / questions.length) * 100);
      onComplete(finalScore);
    }
  };

  // Progress Bar Calculation
  const progress = ((currentQIndex + (isSubmitted ? 1 : 0)) / questions.length) * 100;

  return (
    <div className="min-h-screen bg-indigo-50 flex items-center justify-center p-4">
      <div className="bg-white max-w-2xl w-full rounded-2xl shadow-xl overflow-hidden">
        {/* Header */}
        <div className="bg-indigo-600 p-6 text-white flex justify-between items-center">
          <h2 className="text-xl font-bold flex items-center gap-2">
            <Award className="text-yellow-300" /> Daily Quiz
          </h2>
          <span className="text-indigo-200 text-sm font-medium">Question {currentQIndex + 1} of {questions.length}</span>
        </div>

        {/* Progress Line */}
        <div className="h-1 bg-gray-100 w-full">
            <div className="h-full bg-yellow-400 transition-all duration-500" style={{ width: `${progress}%` }}></div>
        </div>

        <div className="p-8">
          <h3 className="text-lg font-semibold text-gray-800 mb-6 leading-relaxed">
            {question.question}
          </h3>

          <div className="space-y-3">
            {question.options.map((option, idx) => {
              let btnClass = "w-full text-left p-4 rounded-xl border-2 transition-all duration-200 relative ";
              
              if (isSubmitted) {
                if (idx === question.correctOptionIndex) {
                  btnClass += "bg-green-50 border-green-500 text-green-800";
                } else if (idx === selectedOption) {
                  btnClass += "bg-red-50 border-red-500 text-red-800";
                } else {
                  btnClass += "border-gray-100 text-gray-400 opacity-60";
                }
              } else {
                if (idx === selectedOption) {
                  btnClass += "border-indigo-500 bg-indigo-50 text-indigo-900";
                } else {
                  btnClass += "border-gray-100 hover:border-indigo-200 hover:bg-gray-50 text-gray-700";
                }
              }

              return (
                <button
                  key={idx}
                  onClick={() => !isSubmitted && setSelectedOption(idx)}
                  disabled={isSubmitted}
                  className={btnClass}
                >
                  <div className="flex items-center justify-between">
                    <span>{option}</span>
                    {isSubmitted && idx === question.correctOptionIndex && <Check size={20} className="text-green-600" />}
                    {isSubmitted && idx === selectedOption && idx !== question.correctOptionIndex && <X size={20} className="text-red-500" />}
                  </div>
                </button>
              );
            })}
          </div>

          {/* Explanation Area */}
          {isSubmitted && (
            <div className="mt-6 p-4 bg-blue-50 rounded-xl border border-blue-100 animate-fade-in">
              <div className="flex items-start gap-3">
                <AlertCircle className="text-blue-500 mt-1 shrink-0" size={20} />
                <div>
                  <h4 className="font-semibold text-blue-900 text-sm mb-1">Feedback</h4>
                  <p className="text-blue-800 text-sm leading-relaxed">{question.explanation}</p>
                </div>
              </div>
            </div>
          )}
        </div>

        <div className="p-6 bg-gray-50 border-t border-gray-100 flex justify-end">
          {!isSubmitted ? (
            <button
              onClick={handleSubmitAnswer}
              disabled={selectedOption === null}
              className="bg-indigo-600 text-white px-6 py-3 rounded-lg font-medium hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed transition"
            >
              Check Answer
            </button>
          ) : (
            <button
              onClick={handleNext}
              className="bg-gray-900 text-white px-6 py-3 rounded-lg font-medium hover:bg-gray-800 transition flex items-center gap-2"
            >
              {currentQIndex < questions.length - 1 ? "Next Question" : "Finish Quiz"} <ArrowRight size={18} />
            </button>
          )}
        </div>
      </div>
    </div>
  );
});

export default Quiz;