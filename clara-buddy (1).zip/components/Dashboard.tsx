import React, { useMemo, useState } from 'react';
import { UserState, DailyPlan, MicroGoal, Subject } from '../types';
import { BarChart, Bar, XAxis, YAxis, Tooltip as RechartsTooltip, ResponsiveContainer, Cell, CartesianGrid } from 'recharts';
import { CheckCircle2, Circle, Play, Award, Zap, ChevronDown, ChevronUp, Sparkles, History as HistoryIcon, CalendarClock, Loader2, Lock, Trash2, AlertTriangle, ArrowUp, ArrowDown, Minus, TrendingUp } from 'lucide-react';

interface Props {
  user: UserState;
  dailyPlan: DailyPlan | null;
  loading: boolean;
  activityStats: { today: number; yesterday: number };
  onStartGoal: (goal: MicroGoal) => void;
  onStartQuiz: (subjectId: string) => void;
  onViewHistory: () => void;
  onNextDay: () => void;
  onDeleteSubject: (subjectId: string) => void;
  onCheckIn: () => void;
}

const Dashboard: React.FC<Props> = React.memo(({ user, dailyPlan, loading, activityStats, onStartGoal, onStartQuiz, onViewHistory, onNextDay, onDeleteSubject, onCheckIn }) => {
  const [expandedSubjectId, setExpandedSubjectId] = useState<string | null>(null);
  const [subjectToDelete, setSubjectToDelete] = useState<Subject | null>(null);

  // Memoize performance data calculation
  const performanceData = useMemo(() => {
    let totalDailyGoals = 0;
    let completedDailyGoals = 0;
    
    dailyPlan?.subjectPlans.forEach(sp => {
      totalDailyGoals += sp.goals.length + (sp.quiz ? 1 : 0);
      completedDailyGoals += sp.goals.filter(g => g.isCompleted).length + (sp.quiz?.completed ? 1 : 0);
    });

    const overallProgress = totalDailyGoals > 0 ? (completedDailyGoals / totalDailyGoals) * 100 : 0;

    return Array.from({ length: 7 }).map((_, i) => {
      const day = new Date();
      day.setDate(day.getDate() - (6 - i));
      return {
          day: day.toLocaleDateString('en-US', { weekday: 'short' }),
          score: i === 6 ? Math.round(overallProgress) : Math.floor(Math.random() * 60) + 20
      };
    });
  }, [dailyPlan]);

  // Data for Subject Score Graph
  const subjectScoreData = useMemo(() => {
    return user.subjects.map(s => ({
      name: s.name,
      score: s.currentScore
    }));
  }, [user.subjects]);

  const allTasksCompleted = useMemo(() => {
    if (!dailyPlan || dailyPlan.subjectPlans.length === 0) return false;
    
    return dailyPlan.subjectPlans.every(plan => {
      if (plan.isLoading) return false;
      const goalsDone = plan.goals.every(g => g.isCompleted);
      const quizDone = plan.quiz ? plan.quiz.completed : true; 
      return goalsDone && quizDone;
    });
  }, [dailyPlan]);

  const toggleSubject = (id: string) => {
    setExpandedSubjectId(prev => prev === id ? null : id);
  };

  const confirmDelete = () => {
    if (subjectToDelete) {
      onDeleteSubject(subjectToDelete.id);
      setSubjectToDelete(null);
    }
  };

  if (loading && !dailyPlan) {
    return (
      <div className="h-screen flex flex-col items-center justify-center text-gray-500 animate-pulse bg-gray-50">
        <div className="p-4 bg-white rounded-full shadow-lg mb-4">
            <Zap size={32} className="text-indigo-500" />
        </div>
        <p className="text-lg font-medium text-gray-700">Clara is curating your tasks...</p>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto p-4 md:p-8 space-y-8 pb-20 bg-gray-50 min-h-screen font-sans">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4 animate-fade-in-down">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Hello, {user.name}</h1>
          <p className="text-gray-500 mt-1">Ready to build confidence today?</p>
        </div>
        
        <div className="flex items-center gap-3 flex-wrap">
           <button 
             onClick={onCheckIn}
             className="bg-indigo-50 px-4 py-2 rounded-xl shadow-sm border border-indigo-100 flex items-center gap-2 text-indigo-700 hover:bg-indigo-100 transition-all"
           >
             <TrendingUp size={18} />
             <span className="font-bold text-sm hidden md:inline">Check-in</span>
           </button>

           <button 
             onClick={onViewHistory}
             className="bg-white px-4 py-2 rounded-xl shadow-sm border border-gray-200 flex items-center gap-2 text-gray-700 hover:bg-gray-50 hover:border-gray-300 transition-all"
           >
             <HistoryIcon size={18} />
             <span className="font-bold text-sm hidden md:inline">History</span>
           </button>
           
           <div className="bg-white px-4 py-2 rounded-xl shadow-sm border border-gray-200 flex items-center gap-2">
             <Zap size={18} className="text-amber-500" fill="currentColor" />
             <span className="font-bold text-gray-700 text-sm">{user.streak} Day Streak</span>
           </div>
        </div>
      </div>

      {/* Encouragement Banner */}
      {dailyPlan?.encouragement && (
        <div className="bg-white border-l-4 border-indigo-500 rounded-r-xl shadow-sm p-5 flex items-start gap-4 animate-fade-in">
             <div className="bg-indigo-50 p-2 rounded-full mt-1">
                <Sparkles size={20} className="text-indigo-600" />
             </div>
             <div>
                <p className="text-lg font-bold text-gray-800">"{dailyPlan.encouragement.message}"</p>
                <p className="text-gray-500 text-sm mt-1">{dailyPlan.encouragement.reason}</p>
             </div>
        </div>
      )}

      {/* Daily Activity Stats Card */}
      <div className="bg-white p-5 rounded-2xl shadow-sm border border-gray-100 flex items-center justify-between animate-fade-in">
          <div className="flex flex-col">
              <span className="text-sm font-semibold text-gray-400 uppercase tracking-wider">Today's Activity</span>
              <span className="text-3xl font-bold text-gray-900">{activityStats.today} <span className="text-sm text-gray-500 font-normal">tasks completed</span></span>
          </div>
          <div className="h-10 w-px bg-gray-100 mx-4"></div>
          <div className="flex flex-col items-end">
               <span className="text-xs font-semibold text-gray-400 mb-1">vs Yesterday</span>
               <div className="flex items-center gap-2">
                  <span className="text-xl font-bold text-gray-700">{activityStats.yesterday}</span>
                  {activityStats.today > activityStats.yesterday ? (
                      <div className="flex items-center text-green-500 bg-green-50 px-2 py-0.5 rounded-full text-xs font-bold">
                          <ArrowUp size={12} /> {activityStats.today - activityStats.yesterday}
                      </div>
                  ) : activityStats.today < activityStats.yesterday ? (
                      <div className="flex items-center text-red-400 bg-red-50 px-2 py-0.5 rounded-full text-xs font-bold">
                          <ArrowDown size={12} /> {activityStats.yesterday - activityStats.today}
                      </div>
                  ) : (
                      <div className="flex items-center text-gray-400 bg-gray-100 px-2 py-0.5 rounded-full text-xs font-bold">
                          <Minus size={12} />
                      </div>
                  )}
               </div>
          </div>
      </div>

      {/* Subject Blocks Grid */}
      <div className="grid grid-cols-1 gap-4">
        {dailyPlan?.subjectPlans.map((plan) => {
            const subject = user.subjects.find(s => s.id === plan.subjectId);
            if (!subject) return null;

            if (plan.isLoading) {
                return (
                    <div key={plan.subjectId} className="bg-white rounded-2xl border border-gray-200 p-5 shadow-sm animate-pulse">
                        <div className="flex items-center justify-between mb-4">
                            <div className="h-6 bg-gray-200 rounded w-1/3"></div>
                            <div className="h-8 w-8 bg-gray-200 rounded-full"></div>
                        </div>
                        <div className="h-2 bg-gray-100 rounded-full w-full mb-2"></div>
                        <div className="flex items-center gap-2 text-sm text-gray-400">
                             <Loader2 size={16} className="animate-spin" />
                             Generating learning plan...
                        </div>
                    </div>
                );
            }

            const isExpanded = expandedSubjectId === subject.id;
            const subjectTotal = plan.goals.length + (plan.quiz ? 1 : 0);
            const subjectCompleted = plan.goals.filter(g => g.isCompleted).length + (plan.quiz?.completed ? 1 : 0);
            const subjectProgress = subjectTotal > 0 ? (subjectCompleted / subjectTotal) * 100 : 0;
            const hasQuiz = plan.quiz && plan.quiz.questions.length > 0;

            return (
                <div 
                    key={plan.subjectId} 
                    className={`bg-white rounded-2xl border transition-all duration-300 overflow-hidden ${isExpanded ? 'shadow-lg border-indigo-200 ring-1 ring-indigo-100' : 'shadow-sm border-gray-200 hover:border-indigo-200'}`}
                >
                    {/* Block Header */}
                    <div 
                        onClick={() => toggleSubject(subject.id)}
                        className="p-5 cursor-pointer flex items-center justify-between group bg-white relative"
                    >
                        <div className="flex-1">
                            <div className="flex items-center gap-3 mb-2">
                                <h3 className="text-xl font-bold text-gray-800 group-hover:text-indigo-600 transition-colors">{subject.name}</h3>
                            </div>
                            
                            <div className="flex items-center gap-3 max-w-md">
                                <div className="flex-1 h-2 bg-gray-100 rounded-full overflow-hidden">
                                    <div 
                                        className={`h-full rounded-full transition-all duration-700 ${subjectProgress === 100 ? 'bg-green-500' : 'bg-indigo-500'}`}
                                        style={{ width: `${subjectProgress}%` }}
                                    ></div>
                                </div>
                                <span className="text-xs font-bold text-gray-400">{Math.round(subjectProgress)}%</span>
                            </div>
                        </div>

                        <div className="flex items-center gap-2">
                            <button 
                                onClick={(e) => {
                                    e.stopPropagation();
                                    e.preventDefault();
                                    setSubjectToDelete(subject);
                                }}
                                className="p-2 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-full transition-colors relative z-10"
                                title="Delete Subject"
                            >
                                <Trash2 size={18} />
                            </button>
                            <div className={`p-2 rounded-full transition-colors ${isExpanded ? 'bg-indigo-50 text-indigo-600' : 'text-gray-400 group-hover:bg-gray-50'}`}>
                                {isExpanded ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
                            </div>
                        </div>
                    </div>

                    {/* Detailed Content */}
                    {isExpanded && (
                        <div className="border-t border-gray-100 animate-slide-down bg-gray-50/50">
                            <div className="p-5 space-y-3">
                                <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Today's Tasks</h4>
                                {plan.goals.map(goal => (
                                    <div key={goal.id} className="flex items-center justify-between p-4 bg-white rounded-xl border border-gray-100 shadow-sm hover:shadow-md transition-all">
                                        <div className="flex items-center gap-4">
                                            {goal.isCompleted ? (
                                                <div className="bg-green-100 p-1 rounded-full text-green-600">
                                                    <CheckCircle2 size={18} />
                                                </div>
                                            ) : (
                                                <Circle size={20} className="text-gray-300" />
                                            )}
                                            <div>
                                                <p className={`font-medium ${goal.isCompleted ? 'text-gray-400 line-through' : 'text-gray-800'}`}>
                                                    {goal.title}
                                                </p>
                                            </div>
                                        </div>
                                        {!goal.isCompleted && (
                                            <button 
                                                onClick={(e) => { e.stopPropagation(); onStartGoal(goal); }}
                                                className="bg-indigo-600 text-white px-4 py-2 rounded-lg text-sm font-semibold hover:bg-indigo-700 flex items-center gap-1 transition"
                                            >
                                                Start <Play size={14} fill="currentColor" />
                                            </button>
                                        )}
                                    </div>
                                ))}

                                {hasQuiz ? (
                                    <div className="mt-4 p-4 bg-indigo-100/50 rounded-xl border border-indigo-100 flex items-center justify-between">
                                        <div className="flex items-center gap-3">
                                            <div className="bg-indigo-200 p-2 rounded-lg text-indigo-700">
                                                <Award size={20} />
                                            </div>
                                            <div>
                                                <h4 className="font-bold text-indigo-900 text-sm">Daily Quiz</h4>
                                                <p className="text-xs text-indigo-700 opacity-80">
                                                    {plan.quiz?.completed ? `Score: ${plan.quiz.score}%` : 'Tests ONLY what you just read'}
                                                </p>
                                            </div>
                                        </div>
                                        {!plan.quiz?.completed ? (
                                            <button 
                                                onClick={(e) => { e.stopPropagation(); onStartQuiz(subject.id); }}
                                                className="bg-indigo-600 text-white px-5 py-2 rounded-lg text-sm font-semibold shadow-sm hover:shadow-md hover:bg-indigo-700 transition"
                                            >
                                                Take Quiz
                                            </button>
                                        ) : (
                                            <span className="text-xs font-bold bg-green-100 text-green-700 px-3 py-1 rounded-full">Completed</span>
                                        )}
                                    </div>
                                ) : (
                                    // Fallback UI if no quiz generated (rare but possible with LLMs)
                                    <div className="mt-4 p-3 bg-gray-100 rounded-xl text-center text-xs text-gray-500">
                                        No quiz available for today's session.
                                    </div>
                                )}
                            </div>
                        </div>
                    )}
                </div>
            );
        })}
      </div>

      <div className="flex justify-center mt-8">
        <button 
            onClick={allTasksCompleted ? onNextDay : undefined}
            disabled={!allTasksCompleted}
            className={`group flex items-center gap-3 px-6 py-4 rounded-2xl shadow-xl transition-all ${
                allTasksCompleted 
                ? "bg-gray-900 text-white hover:bg-gray-800 hover:scale-105 active:scale-95 cursor-pointer" 
                : "bg-gray-200 text-gray-400 cursor-not-allowed"
            }`}
        >
            <div>
                <span className={`block text-sm font-medium text-left ${allTasksCompleted ? "text-gray-400" : "text-gray-500"}`}>
                   {allTasksCompleted ? "Finished for today?" : "Complete all tasks to advance"}
                </span>
                <span className="block font-bold">Start Next Day Plan</span>
            </div>
            <div className={`p-2 rounded-full transition ${allTasksCompleted ? "bg-gray-700 group-hover:bg-gray-600" : "bg-gray-300"}`}>
                {allTasksCompleted ? <CalendarClock size={20} /> : <Lock size={20} />}
            </div>
        </button>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-12">
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
           <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-bold text-gray-800">Subject Proficiency</h3>
              <div className="flex items-center gap-2 text-sm text-gray-500">
                  <Award size={16} />
                  <span>Current Quiz Score Avg (%)</span>
              </div>
           </div>
           <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={subjectScoreData} margin={{ top: 10, right: 10, left: 10, bottom: 0 }}>
                   <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f3f4f6" />
                   <XAxis 
                      dataKey="name" 
                      axisLine={false} 
                      tickLine={false} 
                      tick={{ fill: '#6b7280', fontSize: 12 }} 
                      dy={10}
                      interval={0}
                   />
                   <YAxis 
                      hide={false} 
                      axisLine={false}
                      tickLine={false}
                      domain={[0, 100]}
                      tick={{ fill: '#9ca3af', fontSize: 12 }} 
                   />
                   <RechartsTooltip 
                      cursor={{ fill: '#f3f4f6' }}
                      contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                   />
                   <Bar dataKey="score" radius={[6, 6, 0, 0]} barSize={50}>
                      {subjectScoreData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill="#818cf8" />
                      ))}
                   </Bar>
                </BarChart>
              </ResponsiveContainer>
           </div>
        </div>

        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
           <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-bold text-gray-800">Daily Activity</h3>
              <div className="flex items-center gap-2 text-sm text-gray-500">
                  <span className="w-3 h-3 bg-indigo-500 rounded-sm"></span>
                  <span>Completion Rate</span>
              </div>
           </div>
           <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
              <BarChart data={performanceData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <XAxis 
                      dataKey="day" 
                      axisLine={false} 
                      tickLine={false} 
                      tick={{ fill: '#9ca3af', fontSize: 12 }} 
                      dy={10}
                  />
                  <YAxis hide domain={[0, 100]} />
                  <RechartsTooltip 
                      cursor={{ fill: '#f3f4f6' }}
                      contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                  />
                  <Bar dataKey="score" radius={[6, 6, 6, 6]} barSize={40}>
                      {performanceData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={index === 6 ? '#6366f1' : '#e5e7eb'} />
                      ))}
                  </Bar>
              </BarChart>
              </ResponsiveContainer>
           </div>
        </div>
      </div>

      {/* Delete Confirmation Modal */}
      {subjectToDelete && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4 animate-fade-in backdrop-blur-sm">
          <div className="bg-white rounded-2xl shadow-xl max-w-sm w-full p-6 animate-scale-up">
             <div className="flex items-start gap-4 mb-4">
                <div className="bg-red-100 p-3 rounded-full text-red-600 shrink-0">
                    <AlertTriangle size={24} />
                </div>
                <div>
                    <h3 className="text-lg font-bold text-gray-900">Delete Subject?</h3>
                    <p className="text-gray-500 text-sm mt-1">
                        Are you sure you want to remove <span className="font-bold text-gray-800">{subjectToDelete.name}</span>? 
                        This will delete all progress and history for this subject.
                    </p>
                </div>
             </div>
             
             <div className="flex gap-3 justify-end">
                <button 
                  onClick={() => setSubjectToDelete(null)}
                  className="px-4 py-2 text-gray-600 font-medium hover:bg-gray-100 rounded-lg transition"
                >
                    Cancel
                </button>
                <button 
                  onClick={confirmDelete}
                  className="px-4 py-2 bg-red-600 text-white font-bold rounded-lg hover:bg-red-700 shadow-lg shadow-red-200 transition"
                >
                    Delete Forever
                </button>
             </div>
          </div>
        </div>
      )}
    </div>
  );
});

export default Dashboard;