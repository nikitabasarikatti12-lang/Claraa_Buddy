import React, { useState } from 'react';
import { UserState, Subject, Chapter } from '../types';
import { Plus, Trash2, ArrowRight, BookOpen, ArrowLeft, Layers } from 'lucide-react';

interface Props {
  user: UserState | null;
  onComplete: (user: UserState) => void;
  onBack: () => void;
}

const Onboarding: React.FC<Props> = React.memo(({ user, onComplete, onBack }) => {
  const [name, setName] = useState(user?.name || '');
  const [subjects, setSubjects] = useState<Subject[]>([
    { 
      id: '1', 
      name: '', 
      chapters: [{ id: 'c1', title: '', details: '' }], 
      currentScore: 50, 
      confidenceLevel: 5,
      confidenceHistory: [{ date: new Date().toISOString().split('T')[0], score: 5 }] 
    }
  ]);
  const [step, setStep] = useState(1);

  const addSubject = () => {
    setSubjects([...subjects, { 
      id: Date.now().toString(), 
      name: '', 
      chapters: [{ id: `c-${Date.now()}-1`, title: '', details: '' }], 
      currentScore: 50, 
      confidenceLevel: 5,
      confidenceHistory: [{ date: new Date().toISOString().split('T')[0], score: 5 }]
    }]);
  };

  const updateSubject = (index: number, field: keyof Subject, value: any) => {
    const newSubjects = [...subjects];
    newSubjects[index] = { ...newSubjects[index], [field]: value };
    setSubjects(newSubjects);
  };

  const removeSubject = (index: number) => {
    if (subjects.length > 1) {
      setSubjects(subjects.filter((_, i) => i !== index));
    }
  };

  const updateChapterCount = (subjectIndex: number, count: number) => {
    const subject = subjects[subjectIndex];
    const currentChapters = subject.chapters;
    let newChapters = [...currentChapters];

    if (count > currentChapters.length) {
      // Add chapters
      for (let i = currentChapters.length; i < count; i++) {
        newChapters.push({ id: `c-${Date.now()}-${i}`, title: '', details: '' });
      }
    } else if (count < currentChapters.length) {
      // Remove chapters
      newChapters = newChapters.slice(0, count);
    }
    
    // Ensure at least one chapter
    if (newChapters.length === 0) newChapters = [{ id: `c-${Date.now()}-0`, title: '', details: '' }];

    updateSubject(subjectIndex, 'chapters', newChapters);
  };

  const updateChapter = (subjectIndex: number, chapterIndex: number, field: keyof Chapter, value: string) => {
    const newSubjects = [...subjects];
    const newChapters = [...newSubjects[subjectIndex].chapters];
    newChapters[chapterIndex] = { ...newChapters[chapterIndex], [field]: value };
    newSubjects[subjectIndex] = { ...newSubjects[subjectIndex], chapters: newChapters };
    setSubjects(newSubjects);
  };

  const handleSubmit = () => {
    const newUser: UserState = {
      username: user?.username || '',
      name,
      subjects: subjects.filter(s => s.name.trim() !== ''),
      isOnboarded: true,
      streak: 1,
      lastLoginDate: new Date().toISOString().split('T')[0],
      confidenceHistory: [{ date: new Date().toISOString().split('T')[0], score: 5 }],
      activityLog: []
    };
    onComplete(newUser);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50 flex items-center justify-center p-4 font-sans">
      <div className="bg-white max-w-3xl w-full rounded-3xl shadow-xl p-8 md:p-12 transition-all border border-gray-100">
        <div className="mb-8 text-center">
          <h1 className="text-3xl font-bold text-gray-800 mb-2">Create your account</h1>
          <p className="text-gray-500">Let's set up your personalized study plan.</p>
        </div>

        {step === 1 ? (
          <div className="space-y-8">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">What should we call you?</label>
              <input
                type="text"
                className="w-full p-4 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-green-400 focus:border-transparent outline-none transition"
                placeholder="Enter your name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                autoFocus
              />
            </div>
            
            <div className="flex gap-4">
              <button 
                onClick={onBack}
                className="px-6 py-4 text-gray-500 font-medium hover:text-gray-800 transition"
              >
                Back
              </button>
              <button
                onClick={() => name && setStep(2)}
                disabled={!name}
                className="flex-1 bg-gray-900 text-white py-4 rounded-xl font-bold hover:bg-gray-800 disabled:opacity-50 transition flex items-center justify-center gap-2 shadow-lg"
              >
                Next Step <ArrowRight size={18} />
              </button>
            </div>
          </div>
        ) : (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-semibold text-gray-800">Add Your Subjects</h2>
              <button onClick={addSubject} className="text-green-600 text-sm font-bold hover:text-green-700 flex items-center gap-1 bg-green-50 px-3 py-1.5 rounded-lg transition-colors">
                <Plus size={16} /> Add Subject
              </button>
            </div>

            <div className="max-h-[60vh] overflow-y-auto space-y-8 pr-2 -mr-2">
              {subjects.map((subject, index) => (
                <div key={subject.id} className="p-6 bg-gray-50 rounded-2xl border border-gray-100 relative group transition-all hover:border-gray-200 shadow-sm">
                  {subjects.length > 1 && (
                    <button 
                      onClick={() => removeSubject(index)}
                      className="absolute top-4 right-4 text-gray-400 hover:text-red-500 opacity-0 group-hover:opacity-100 transition p-1 hover:bg-red-50 rounded-md"
                    >
                      <Trash2 size={18} />
                    </button>
                  )}
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-5 mb-6">
                    <div>
                      <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">Subject Name</label>
                      <input
                        value={subject.name}
                        onChange={(e) => updateSubject(index, 'name', e.target.value)}
                        placeholder="e.g. Mathematics"
                        className="w-full p-3 bg-white border border-gray-200 rounded-lg focus:border-green-400 focus:ring-2 focus:ring-green-100 outline-none transition"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">Current Score (%)</label>
                      <input
                        type="number"
                        value={subject.currentScore}
                        onChange={(e) => updateSubject(index, 'currentScore', Number(e.target.value))}
                        className="w-full p-3 bg-white border border-gray-200 rounded-lg focus:border-green-400 focus:ring-2 focus:ring-green-100 outline-none transition"
                      />
                    </div>
                  </div>

                  <div className="bg-white p-4 rounded-xl border border-gray-200">
                    <div className="flex items-center gap-2 mb-4">
                        <Layers size={18} className="text-indigo-500"/>
                        <span className="font-semibold text-gray-700">Syllabus Structure</span>
                        <div className="ml-auto flex items-center gap-2">
                            <label className="text-xs text-gray-500 font-medium">Number of Chapters:</label>
                            <input 
                                type="number" 
                                min="1" 
                                max="20"
                                value={subject.chapters.length}
                                onChange={(e) => updateChapterCount(index, parseInt(e.target.value) || 1)}
                                className="w-16 p-2 bg-white text-gray-900 font-bold border border-gray-200 rounded-lg text-center text-sm focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 outline-none transition-all"
                            />
                        </div>
                    </div>

                    <div className="space-y-4">
                        {subject.chapters.map((chapter, cIndex) => (
                            <div key={chapter.id} className="grid grid-cols-1 md:grid-cols-3 gap-3 animate-fade-in">
                                <div className="md:col-span-1">
                                    <input
                                        placeholder={`Chapter ${cIndex + 1} Title`}
                                        value={chapter.title}
                                        onChange={(e) => updateChapter(index, cIndex, 'title', e.target.value)}
                                        className="w-full p-2.5 bg-white text-gray-900 border border-gray-200 rounded-lg text-sm focus:border-indigo-400 outline-none"
                                    />
                                </div>
                                <div className="md:col-span-2">
                                    <input
                                        placeholder="Topics (e.g. Integration by parts, definite integrals)"
                                        value={chapter.details}
                                        onChange={(e) => updateChapter(index, cIndex, 'details', e.target.value)}
                                        className="w-full p-2.5 bg-white text-gray-900 border border-gray-200 rounded-lg text-sm focus:border-indigo-400 outline-none"
                                    />
                                </div>
                            </div>
                        ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="flex gap-4 pt-4 border-t border-gray-100">
              <button
                onClick={() => setStep(1)}
                className="px-6 py-3 text-gray-600 hover:bg-gray-100 rounded-xl font-medium transition"
              >
                Back
              </button>
              <button
                onClick={handleSubmit}
                disabled={subjects.some(s => !s.name)}
                className="flex-1 bg-green-600 text-white py-3 rounded-xl font-bold hover:bg-green-700 disabled:opacity-50 transition flex items-center justify-center gap-2 shadow-lg hover:shadow-green-200"
              >
                Finish Setup <BookOpen size={18} />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
});

export default Onboarding;