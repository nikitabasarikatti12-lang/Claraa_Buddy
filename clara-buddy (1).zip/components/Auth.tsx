import React, { useState } from 'react';
import { AppView } from '../types';
import { authService } from '../services/authService';
import { UserState } from '../types';
import { Zap, ArrowRight, Lock, User as UserIcon, AlertCircle } from 'lucide-react';

interface Props {
  view: AppView; // LOGIN or REGISTER
  onSwitchView: (view: AppView) => void;
  onSuccess: (user: UserState) => void;
}

const Auth: React.FC<Props> = ({ view, onSwitchView, onSuccess }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      let user: UserState;
      if (view === AppView.LOGIN) {
        user = await authService.login(username, password);
      } else {
        user = await authService.register(username, password);
      }
      onSuccess(user);
    } catch (err: any) {
      setError(err.message || 'An error occurred');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col items-center justify-center p-4 font-sans">
      <div className="mb-8 flex flex-col items-center">
        <div className="bg-white p-4 rounded-2xl shadow-lg shadow-indigo-100 mb-4">
          <Zap size={40} className="text-indigo-600" fill="currentColor" />
        </div>
        <h1 className="text-3xl font-bold text-gray-900">Clara Buddy</h1>
        <p className="text-gray-500">Your calm, personalized study companion.</p>
      </div>

      <div className="bg-white max-w-md w-full rounded-3xl shadow-xl border border-gray-100 overflow-hidden">
        <div className="p-8">
          <h2 className="text-2xl font-bold text-gray-800 mb-6">
            {view === AppView.LOGIN ? 'Welcome Back' : 'Create Account'}
          </h2>

          {error && (
            <div className="bg-red-50 text-red-600 p-3 rounded-xl flex items-center gap-2 mb-6 text-sm font-medium">
              <AlertCircle size={18} />
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">Username</label>
              <div className="relative">
                <UserIcon className="absolute left-4 top-3.5 text-gray-400" size={20} />
                <input
                  type="text"
                  required
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full pl-12 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition"
                  placeholder="Enter your username"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">Password</label>
              <div className="relative">
                <Lock className="absolute left-4 top-3.5 text-gray-400" size={20} />
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-12 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition"
                  placeholder="••••••••"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-indigo-600 text-white py-4 rounded-xl font-bold hover:bg-indigo-700 shadow-lg shadow-indigo-200 transition flex items-center justify-center gap-2 disabled:opacity-70 mt-4"
            >
              {loading ? (
                'Processing...'
              ) : (
                <>
                  {view === AppView.LOGIN ? 'Log In' : 'Sign Up'} <ArrowRight size={18} />
                </>
              )}
            </button>
          </form>
        </div>
        
        <div className="bg-gray-50 p-6 text-center border-t border-gray-100">
          <p className="text-gray-600 text-sm">
            {view === AppView.LOGIN ? "Don't have an account?" : "Already have an account?"}{' '}
            <button
              onClick={() => {
                setError('');
                onSwitchView(view === AppView.LOGIN ? AppView.REGISTER : AppView.LOGIN);
              }}
              className="text-indigo-600 font-bold hover:underline"
            >
              {view === AppView.LOGIN ? 'Sign Up' : 'Log In'}
            </button>
          </p>
        </div>
      </div>
    </div>
  );
};

export default Auth;
