import React, { useState } from 'react';
import { Subject } from '../types';
import { X, Save, TrendingUp } from 'lucide-react';

interface Props {
  subjects: Subject[];
  onSave: (updates: { subjectId: string; score: number }[]) => void;
  onClose: () => void;
}

const ConfidenceLogger: React.FC<Props> = ({ subjects, onSave, onClose }) => {
  const [scores, setScores] = useState<{ [key: string]: number }>(
    subjects.reduce((acc, s) => ({ ...acc, [s.id]: s.confidenceLevel }), {})
  );

  const handleSave = () => {
    const updates = Object.entries(scores).map(([subjectId, score]) => ({
      subjectId,
      score,
    }));
    onSave(updates);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4 animate-fade-in backdrop-blur-sm">
      <div className="bg-white rounded-3xl shadow-xl max-w-md w-full overflow-hidden border border-indigo-100">
        <div className="bg-indigo-600 p-6 flex justify-between items-center text-white">
          <h2 className="text-xl font-bold flex items-center gap-2">
            <TrendingUp className="text-indigo-200" /> Confidence Check-in
          </h2>
          <button onClick={onClose} className="hover:bg-indigo-700 p-1 rounded-full transition">
            <X size={20} />
          </button>
        </div>
        
        <div className="p-6 space-y-6 max-h-[60vh] overflow-y-auto">
          <p className="text-gray-500 text-sm">How confident do you feel about each subject today? (1 = Low, 10 = High)</p>
          
          {subjects.map(subject => (
            <div key={subject.id} className="space-y-3 p-3 bg-gray-50 rounded-xl border border-gray-100">
              <div className="flex justify-between items-end">
                <label className="font-semibold text-gray-800">{subject.name}</label>
                <span className="text-2xl font-bold text-indigo-600">{scores[subject.id]}<span className="text-sm text-gray-400 font-normal">/10</span></span>
              </div>
              <input 
                type="range" 
                min="1" 
                max="10" 
                step="1"
                value={scores[subject.id]}
                onChange={(e) => setScores({ ...scores, [subject.id]: parseInt(e.target.value) })}
                className="w-full h-2 bg-indigo-200 rounded-lg appearance-none cursor-pointer accent-indigo-600"
              />
              <div className="flex justify-between text-xs text-gray-400 font-medium px-1">
                <span>Anxious</span>
                <span>Confident</span>
              </div>
            </div>
          ))}
        </div>

        <div className="p-6 bg-gray-50 border-t border-gray-100">
          <button 
            onClick={handleSave}
            className="w-full bg-indigo-600 text-white py-3 rounded-xl font-bold hover:bg-indigo-700 shadow-lg shadow-indigo-200 hover:shadow-xl transition flex items-center justify-center gap-2"
          >
            <Save size={18} /> Save Daily Check-in
          </button>
        </div>
      </div>
    </div>
  );
};

export default ConfidenceLogger;