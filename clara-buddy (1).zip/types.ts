export interface Chapter {
  id: string;
  title: string;
  details: string;
}

export interface Subject {
  id: string;
  name: string;
  chapters: Chapter[];
  currentScore: number; // 0-100
  confidenceLevel: number; // 1-10
  confidenceHistory: { date: string; score: number }[];
}

export interface ActivityLog {
  id: string;
  type: 'STUDY' | 'QUIZ';
  date: string; // ISO timestamp
  subjectId: string;
  subjectName: string;
  title: string;
  metric: string; // e.g. "15 min" or "Score: 85%"
}

export interface UserState {
  username: string; // Changed from 'name' to 'username' for auth consistency
  name: string;     // Display name
  subjects: Subject[];
  isOnboarded: boolean;
  streak: number;
  lastLoginDate: string;
  confidenceHistory: { date: string; score: number }[]; // Global confidence
  activityLog: ActivityLog[];
}

export interface MicroGoal {
  id: string;
  subjectId: string;
  title: string;
  durationMinutes: number;
  content: string; // Markdown content for learning
  isCompleted: boolean;
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctOptionIndex: number;
  explanation: string;
}

export interface QuizSession {
  subjectId: string;
  questions: QuizQuestion[];
  completed: boolean;
  score?: number;
}

export interface SubjectDailyPlan {
  subjectId: string;
  goals: MicroGoal[];
  quiz: QuizSession | null;
  isLoading?: boolean; // New flag for incremental loading
}

export interface DailyPlan {
  date: string;
  subjectPlans: SubjectDailyPlan[];
  encouragement: {
    message: string;
    reason: string; // Explainability
  } | null;
}

export enum AppView {
  LOGIN = 'LOGIN',
  REGISTER = 'REGISTER',
  ONBOARDING = 'ONBOARDING',
  DASHBOARD = 'DASHBOARD',
  STUDY_SESSION = 'STUDY_SESSION',
  QUIZ = 'QUIZ',
  HISTORY = 'HISTORY',
}