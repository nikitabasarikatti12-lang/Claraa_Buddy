import React, { useState, useEffect, useCallback, Suspense, useMemo } from 'react';
import { AppView, UserState, DailyPlan, MicroGoal, SubjectDailyPlan, ActivityLog } from './types';
import { generateSubjectDailyContent, generateEncouragement } from './services/geminiService';
import { authService } from './services/authService';
import { Zap, LogOut } from 'lucide-react';
import ConfidenceLogger from './components/ConfidenceLogger';
import Auth from './components/Auth';

// Lazy load components for code splitting optimization
const Onboarding = React.lazy(() => import('./components/Onboarding'));
const Dashboard = React.lazy(() => import('./components/Dashboard'));
const StudySession = React.lazy(() => import('./components/StudySession'));
const Quiz = React.lazy(() => import('./components/Quiz'));
const History = React.lazy(() => import('./components/History'));

const LoadingSpinner = () => (
  <div className="h-screen flex flex-col items-center justify-center text-gray-500 bg-gray-50">
     <div className="p-4 bg-white rounded-full shadow-lg mb-4 animate-bounce">
         <Zap size={32} className="text-indigo-500" />
     </div>
     <p className="text-lg font-medium text-gray-700">Loading your space...</p>
  </div>
);

const App: React.FC = () => {
  const [view, setView] = useState<AppView>(AppView.LOGIN);
  const [user, setUser] = useState<UserState | null>(null);
  const [dailyPlan, setDailyPlan] = useState<DailyPlan | null>(null);
  const [showConfidenceLogger, setShowConfidenceLogger] = useState(false);
  
  // Active session states
  const [activeGoal, setActiveGoal] = useState<MicroGoal | null>(null);
  const [activeQuizSubjectId, setActiveQuizSubjectId] = useState<string | null>(null);
  
  const [loading, setLoading] = useState(false);

  // Initialize App (Check for Session)
  useEffect(() => {
    const currentUser = authService.getCurrentUser();
    if (currentUser) {
      setUser(currentUser);
      if (currentUser.isOnboarded) {
        setView(AppView.DASHBOARD);
      } else {
        setView(AppView.ONBOARDING);
      }
      
      // Load Plan specific to this user
      const savedPlan = localStorage.getItem(`clara_daily_plan_${currentUser.username}`);
      if (savedPlan) {
        try {
          const parsedPlan = JSON.parse(savedPlan);
          const today = new Date().toISOString().split('T')[0];
          if (parsedPlan.date === today) {
            setDailyPlan(parsedPlan);
          }
        } catch (e) {
          console.error("Failed to parse saved plan", e);
        }
      }
    } else {
      setView(AppView.LOGIN);
    }
  }, []);

  // Sync User Changes to DB
  useEffect(() => {
    if (user) {
      authService.updateUser(user);
    }
  }, [user]);

  // Sync Daily Plan to Local Storage (User Specific)
  useEffect(() => {
    if (dailyPlan && user) {
      localStorage.setItem(`clara_daily_plan_${user.username}`, JSON.stringify(dailyPlan));
    }
  }, [dailyPlan, user]);

  // Generate Daily Plan logic
  useEffect(() => {
    if (user && user.isOnboarded && !dailyPlan && view === AppView.DASHBOARD) {
      generatePlan();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user, dailyPlan, view]);

  const handleAuthSuccess = (loggedInUser: UserState) => {
    setUser(loggedInUser);
    if (loggedInUser.isOnboarded) {
      setView(AppView.DASHBOARD);
      
      // Check for existing plan for this user
      const savedPlan = localStorage.getItem(`clara_daily_plan_${loggedInUser.username}`);
      if (savedPlan) {
        const parsedPlan = JSON.parse(savedPlan);
        const today = new Date().toISOString().split('T')[0];
        if (parsedPlan.date === today) {
          setDailyPlan(parsedPlan);
        } else {
            setDailyPlan(null); // Reset if old plan
        }
      } else {
          setDailyPlan(null);
      }
    } else {
      setView(AppView.ONBOARDING);
    }
  };

  const handleLogout = () => {
    authService.logout();
    setUser(null);
    setDailyPlan(null);
    setView(AppView.LOGIN);
  };

  const generatePlan = async () => {
    if (!user) return;
    
    // 1. Initialize Skeleton Plan
    const initialSubjectPlans: SubjectDailyPlan[] = user.subjects.map(s => ({
        subjectId: s.id,
        goals: [],
        quiz: null,
        isLoading: true 
    }));
    
    const skeletonPlan: DailyPlan = {
        date: new Date().toISOString().split('T')[0],
        subjectPlans: initialSubjectPlans,
        encouragement: null
    };
    
    setDailyPlan(skeletonPlan);

    // 2. Trigger Subject Generators Sequentially
    for (let i = 0; i < user.subjects.length; i++) {
        const subject = user.subjects[i];
        
        try {
            if (i > 0) {
                await new Promise(resolve => setTimeout(resolve, 4000));
            }

            const content = await generateSubjectDailyContent(subject);
            
            const goals: MicroGoal[] = content.topics.map((t, k) => ({
                id: `g-${subject.id}-${Date.now()}-${k}`,
                subjectId: subject.id,
                title: t.title,
                content: t.content,
                durationMinutes: 0,
                isCompleted: false
            }));

            // Update state incrementally
            setDailyPlan(prev => {
                if (!prev) return null;
                return {
                    ...prev,
                    subjectPlans: prev.subjectPlans.map(sp => 
                        sp.subjectId === subject.id 
                        ? { 
                            subjectId: subject.id, 
                            goals, 
                            quiz: content.quizQuestions.length > 0 ? { subjectId: subject.id, questions: content.quizQuestions, completed: false } : null,
                            isLoading: false 
                          } 
                        : sp
                    )
                };
            });

        } catch (err) {
             console.error(`Error generating for subject ${subject.name}`, err);
             setDailyPlan(prev => {
                if (!prev) return null;
                return {
                    ...prev,
                    subjectPlans: prev.subjectPlans.map(sp => 
                        sp.subjectId === subject.id ? { ...sp, isLoading: false } : sp
                    )
                }
             });
        }
    }

    // 3. Trigger Encouragement
    try {
         await new Promise(resolve => setTimeout(resolve, 1000));
         const enc = await generateEncouragement(user.name, user.streak, user.confidenceHistory);
         setDailyPlan(prev => prev ? { ...prev, encouragement: enc } : null);
    } catch (e) {
         console.warn("Encouragement generation skipped");
    }
  };

  const handleNextDay = useCallback(() => {
    if (!user) return;
    const updatedUser = {
        ...user,
        streak: user.streak + 1,
        lastLoginDate: new Date().toISOString().split('T')[0] 
    };
    setUser(updatedUser);
    setDailyPlan(null);
    localStorage.removeItem(`clara_daily_plan_${user.username}`);
  }, [user]);

  const handleOnboardingComplete = useCallback((newUser: UserState) => {
    const completedUser = { ...newUser, isOnboarded: true };
    setUser(completedUser);
    setView(AppView.DASHBOARD);
  }, []);

  const deleteSubject = useCallback((subjectId: string) => {
    setUser(prevUser => {
      if (!prevUser) return null;
      const updatedSubjects = prevUser.subjects.filter(s => s.id !== subjectId);
      return { ...prevUser, subjects: updatedSubjects };
    });

    setDailyPlan(prevPlan => {
      if (!prevPlan) return null;
      const updatedSubjectPlans = prevPlan.subjectPlans.filter(sp => sp.subjectId !== subjectId);
      return { ...prevPlan, subjectPlans: updatedSubjectPlans };
    });
  }, []);

  const startGoal = useCallback((goal: MicroGoal) => {
    setActiveGoal(goal);
    setView(AppView.STUDY_SESSION);
  }, []);

  const completeGoal = useCallback(() => {
    setDailyPlan((prevPlan) => {
      if (!prevPlan || !activeGoal) return prevPlan;
      const updatedSubjectPlans = prevPlan.subjectPlans.map(plan => {
        if (plan.subjectId === activeGoal.subjectId) {
          return {
            ...plan,
            goals: plan.goals.map(g => g.id === activeGoal.id ? { ...g, isCompleted: true } : g)
          };
        }
        return plan;
      });
      return { ...prevPlan, subjectPlans: updatedSubjectPlans };
    });

    setUser((prevUser) => {
      if (!prevUser || !activeGoal) return prevUser;
      const newLog: ActivityLog = {
        id: Date.now().toString(),
        type: 'STUDY',
        date: new Date().toISOString(),
        subjectId: activeGoal.subjectId,
        subjectName: prevUser.subjects.find(s => s.id === activeGoal.subjectId)?.name || 'Unknown Subject',
        title: activeGoal.title,
        metric: 'Completed'
      };
      
      // Fire specialized log event for backend efficiency
      authService.logActivity(prevUser.username, newLog);
      
      return { ...prevUser, activityLog: [...prevUser.activityLog, newLog] };
    });

    setView(AppView.DASHBOARD);
    setActiveGoal(null);
  }, [activeGoal]);

  const startQuiz = useCallback((subjectId: string) => {
    setActiveQuizSubjectId(subjectId);
    setView(AppView.QUIZ);
  }, []);

  const completeQuiz = useCallback((score: number) => {
    setDailyPlan((prevPlan) => {
      if (!prevPlan || !activeQuizSubjectId) return prevPlan;
      const updatedSubjectPlans = prevPlan.subjectPlans.map(plan => {
        if (plan.subjectId === activeQuizSubjectId && plan.quiz) {
          return { ...plan, quiz: { ...plan.quiz, completed: true, score } };
        }
        return plan;
      });
      return { ...prevPlan, subjectPlans: updatedSubjectPlans };
    });

    setUser((prevUser) => {
      if (!prevUser || !activeQuizSubjectId) return prevUser;
      let confidenceDelta = 0;
      if (score === 100) confidenceDelta = 1.0;
      else if (score >= 66) confidenceDelta = 0.5;
      else if (score >= 33) confidenceDelta = 0;
      else confidenceDelta = -0.5;

      const updatedSubjects = prevUser.subjects.map(s => {
        if (s.id === activeQuizSubjectId) {
          const currentSubjectConfidence = s.confidenceLevel;
          const newSubjectConfidence = Math.max(1, Math.min(10, Number((currentSubjectConfidence + confidenceDelta).toFixed(1))));
          const newScore = Math.round((s.currentScore * 0.9) + (score * 0.1));
          const today = new Date().toISOString().split('T')[0];
          const history = s.confidenceHistory.filter(h => h.date !== today);
          return { 
             ...s, 
             currentScore: newScore,
             confidenceLevel: newSubjectConfidence,
             confidenceHistory: [...history, { date: today, score: newSubjectConfidence }]
          };
        }
        return s;
      });

      const totalConf = updatedSubjects.reduce((acc, curr) => acc + curr.confidenceLevel, 0);
      const globalConfidence = Number((totalConf / updatedSubjects.length).toFixed(1));
      const subjectName = prevUser.subjects.find(s => s.id === activeQuizSubjectId)?.name || 'Unknown Subject';
      const newLog: ActivityLog = {
        id: Date.now().toString(),
        type: 'QUIZ',
        date: new Date().toISOString(),
        subjectId: activeQuizSubjectId,
        subjectName: subjectName,
        title: 'Daily Knowledge Check',
        metric: `Score: ${score}%`
      };

      // Fire specialized log event for backend efficiency
      authService.logActivity(prevUser.username, newLog);

      return {
        ...prevUser,
        subjects: updatedSubjects,
        confidenceHistory: [...prevUser.confidenceHistory, { date: new Date().toISOString().split('T')[0], score: globalConfidence }],
        activityLog: [...prevUser.activityLog, newLog]
      };
    });

    setActiveQuizSubjectId(null);
    setView(AppView.DASHBOARD);
  }, [activeQuizSubjectId]);

  const handleConfidenceUpdate = useCallback((updates: { subjectId: string; score: number }[]) => {
    setUser(prevUser => {
      if (!prevUser) return null;
      const today = new Date().toISOString().split('T')[0];
      const updatedSubjects = prevUser.subjects.map(s => {
        const update = updates.find(u => u.subjectId === s.id);
        if (update) {
           const history = s.confidenceHistory.filter(h => h.date !== today);
           return { ...s, confidenceLevel: update.score, confidenceHistory: [...history, { date: today, score: update.score }] };
        }
        return s;
      });
      const totalConf = updatedSubjects.reduce((acc, s) => acc + s.confidenceLevel, 0);
      const avgConf = Number((totalConf / updatedSubjects.length).toFixed(1));
      const globalHistory = prevUser.confidenceHistory.filter(h => h.date !== today);
      return { ...prevUser, subjects: updatedSubjects, confidenceHistory: [...globalHistory, { date: today, score: avgConf }] };
    });
  }, []);

  const getActiveQuizQuestions = useCallback(() => {
    if (!dailyPlan || !activeQuizSubjectId) return [];
    const plan = dailyPlan.subjectPlans.find(p => p.subjectId === activeQuizSubjectId);
    return plan?.quiz?.questions || [];
  }, [dailyPlan, activeQuizSubjectId]);

  const handleViewHistory = useCallback(() => setView(AppView.HISTORY), []);
  const handleBackToDashboard = useCallback(() => setView(AppView.DASHBOARD), []);

  const activityStats = useMemo(() => {
    if (!user) return { today: 0, yesterday: 0 };
    const today = new Date().toISOString().split('T')[0];
    const yesterdayDate = new Date();
    yesterdayDate.setDate(yesterdayDate.getDate() - 1);
    const yesterday = yesterdayDate.toISOString().split('T')[0];
    const todayCount = user.activityLog.filter(l => l.date.startsWith(today)).length;
    const yesterdayCount = user.activityLog.filter(l => l.date.startsWith(yesterday)).length;
    return { today: todayCount, yesterday: yesterdayCount };
  }, [user]);

  // Handle Logout Button render
  const LogoutButton = () => (
      <button onClick={handleLogout} className="fixed bottom-4 right-4 bg-gray-900 text-white p-3 rounded-full shadow-lg hover:bg-gray-800 transition z-50 flex items-center gap-2 pr-4">
          <LogOut size={18} /> <span className="text-sm font-bold">Logout</span>
      </button>
  );

  return (
    <div className="font-sans text-gray-900 bg-gray-50 min-h-screen relative">
      <Suspense fallback={<LoadingSpinner />}>
        
        {(view === AppView.LOGIN || view === AppView.REGISTER) && (
          <Auth 
            view={view} 
            onSwitchView={setView} 
            onSuccess={handleAuthSuccess} 
          />
        )}

        {view === AppView.ONBOARDING && (
          <Onboarding user={user} onComplete={handleOnboardingComplete} onBack={handleLogout} />
        )}
        
        {view === AppView.DASHBOARD && user && (
          <>
            <Dashboard 
              user={user} 
              dailyPlan={dailyPlan} 
              loading={loading}
              onStartGoal={startGoal}
              onStartQuiz={startQuiz}
              onViewHistory={handleViewHistory}
              onNextDay={handleNextDay}
              onDeleteSubject={deleteSubject}
              activityStats={activityStats}
              onCheckIn={() => setShowConfidenceLogger(true)}
            />
            {showConfidenceLogger && (
              <ConfidenceLogger 
                subjects={user.subjects}
                onSave={handleConfidenceUpdate}
                onClose={() => setShowConfidenceLogger(false)}
              />
            )}
            <LogoutButton />
          </>
        )}

        {view === AppView.STUDY_SESSION && activeGoal && (
          <StudySession 
            goal={activeGoal} 
            onComplete={completeGoal} 
            onExit={handleBackToDashboard} 
          />
        )}

        {view === AppView.QUIZ && activeQuizSubjectId && (
          <Quiz 
            questions={getActiveQuizQuestions()} 
            onComplete={completeQuiz} 
          />
        )}

        {view === AppView.HISTORY && user && (
          <History 
            logs={user.activityLog} 
            onBack={handleBackToDashboard} 
          />
        )}
      </Suspense>
    </div>
  );
};

export default App;