/**
 * Clara Buddy Backend Server
 * 
 * Dependencies to install:
 * npm install express pg cors bcrypt dotenv
 */

const express = require('express');
const { Pool } = require('pg');
const cors = require('cors');
const bcrypt = require('bcrypt');
require('dotenv').config();

const app = express();
const port = process.env.PORT || 3001;

// Middleware
app.use(cors());
app.use(express.json());

// Database Connection
const pool = new Pool({
  user: process.env.DB_USER || 'postgres',
  host: process.env.DB_HOST || 'localhost',
  database: process.env.DB_NAME || 'clara_buddy',
  password: process.env.DB_PASSWORD || 'password',
  port: process.env.DB_PORT || 5432,
});

// Helper: Get full user object structure
const buildUserObject = async (userRow) => {
    // Fetch logs
    const logsRes = await pool.query('SELECT * FROM activity_logs WHERE user_id = $1 ORDER BY date DESC', [userRow.id]);
    
    // Fetch confidence history
    const confRes = await pool.query('SELECT date, score FROM confidence_history WHERE user_id = $1 ORDER BY date ASC', [userRow.id]);
    
    return {
        username: userRow.username,
        name: userRow.name,
        subjects: userRow.subjects || [],
        isOnboarded: userRow.is_onboarded,
        streak: userRow.streak,
        lastLoginDate: userRow.last_login_date ? userRow.last_login_date.toISOString().split('T')[0] : new Date().toISOString().split('T')[0],
        activityLog: logsRes.rows.map(row => ({
            ...row,
            date: row.date.toISOString()
        })),
        confidenceHistory: confRes.rows.map(row => ({
            date: typeof row.date === 'string' ? row.date : row.date.toISOString().split('T')[0],
            score: parseFloat(row.score)
        }))
    };
};

// Routes

// 1. Register
app.post('/api/register', async (req, res) => {
  const { username, password } = req.body;
  try {
    const userCheck = await pool.query('SELECT * FROM users WHERE username = $1', [username]);
    if (userCheck.rows.length > 0) {
      return res.status(400).json({ error: 'Username already exists' });
    }

    const salt = await bcrypt.genSalt(10);
    const hash = await bcrypt.hash(password, salt);

    const newUser = await pool.query(
      `INSERT INTO users (username, password_hash, name, subjects, is_onboarded, streak, last_login_date) 
       VALUES ($1, $2, $1, $3, $4, $5, CURRENT_DATE) RETURNING *`,
      [username, hash, '[]', false, 0]
    );

    const fullUser = await buildUserObject(newUser.rows[0]);
    res.json(fullUser);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

// 2. Login
app.post('/api/login', async (req, res) => {
  const { username, password } = req.body;
  try {
    const userRes = await pool.query('SELECT * FROM users WHERE username = $1', [username]);
    if (userRes.rows.length === 0) return res.status(400).json({ error: 'Invalid credentials' });

    const user = userRes.rows[0];
    const validPass = await bcrypt.compare(password, user.password_hash);
    if (!validPass) return res.status(400).json({ error: 'Invalid credentials' });

    // Update login date
    await pool.query('UPDATE users SET last_login_date = CURRENT_DATE WHERE id = $1', [user.id]);

    const fullUser = await buildUserObject(user);
    res.json(fullUser);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

// 3. Update User State (Sync)
app.put('/api/user/update', async (req, res) => {
  const { username, subjects, streak, isOnboarded, activityLog, confidenceHistory } = req.body;
  
  if (!username) return res.status(400).json({ error: 'Username required' });

  try {
    // Get User ID
    const userRes = await pool.query('SELECT id FROM users WHERE username = $1', [username]);
    if (userRes.rows.length === 0) return res.status(404).json({ error: 'User not found' });
    const userId = userRes.rows[0].id;

    // Update Core Data
    await pool.query(
        'UPDATE users SET subjects = $1, streak = $2, is_onboarded = $3 WHERE id = $4',
        [JSON.stringify(subjects), streak, isOnboarded, userId]
    );

    // Sync Activity Logs (Ideally, only send *new* logs, but for simplicity we sync checks)
    // A better approach for production is to have a specific /api/log endpoint
    if (activityLog && activityLog.length > 0) {
        const latestLog = activityLog[activityLog.length - 1];
        // Simple deduplication check: check if this ID exists
        const logCheck = await pool.query('SELECT id FROM activity_logs WHERE id = $1', [latestLog.id]); // Assuming ID is passed from frontend as unique string (timestamp)
        // Note: In schema id is SERIAL, but frontend generates timestamp IDs. 
        // We'll trust frontend 'type' and 'date' for now, or just insert new ones.
        
        // Backend implementation detail: Better to have specific endpoints for "logActivity" 
        // to avoid resending the whole array. For this demo, we skip full array sync to avoid complexity.
    }

    // Sync Confidence (Just insert the latest if needed)
    if (confidenceHistory && confidenceHistory.length > 0) {
        const lastConf = confidenceHistory[confidenceHistory.length - 1];
        // Upsert based on date/user
        await pool.query(
            `INSERT INTO confidence_history (user_id, date, score) 
             VALUES ($1, $2, $3) 
             ON CONFLICT DO NOTHING`, // Note: Requires unique constraint on user_id+date if we want strict upsert
            [userId, lastConf.date, lastConf.score]
        );
    }

    res.json({ success: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

// 4. Specific Endpoint for Activity Logging
app.post('/api/log', async (req, res) => {
    const { username, log } = req.body;
    try {
        const userRes = await pool.query('SELECT id FROM users WHERE username = $1', [username]);
        if (userRes.rows.length === 0) return res.status(404).json({ error: 'User not found' });
        
        await pool.query(
            `INSERT INTO activity_logs (user_id, type, date, subject_id, subject_name, title, metric)
             VALUES ($1, $2, $3, $4, $5, $6, $7)`,
            [userRes.rows[0].id, log.type, log.date, log.subjectId, log.subjectName, log.title, log.metric]
        );
        res.json({ success: true });
    } catch(err) {
        res.status(500).json({ error: 'Log error' });
    }
});

app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
